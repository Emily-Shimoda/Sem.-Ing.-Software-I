<?php
session_start();
if($_SESSION['rol'] !=1){
    header("location: index.php");
}
  include "conexion.php";
  if(empty($_GET)){
          header("location: mostraradmin.php");
          mysqli_close($conexion);
        }
        $iddel = $_GET['id'];
        $delete = mysqli_query($conexion,"UPDATE admin SET estatus=0 WHERE id=$iddel");
            if($delete){
                 echo"<script>alert('Eliminado');</scriptalert>";
                header("Location: mostraradmin.php");
                }else{
                    echo"<script>alert('Error');</scriptalert>";
                        header("Location: mostraradmin.php");
                }
            ?>
function confirmacionho(event){
    if(confirm("¿Esta seguro que desea eliminarlo?")){
        return true;
    }else{
        event.preventDefault();
        alert("Acción Cancelada! Registro No Eliminado!");
    }



let linkDeleteho = document.querySelectorAll("del_horario");

for( var i = 0; i < linkDeleteho.length; i++){
    linkDeleteho[i].addEventListener('clik', confirmacionho);
}
}
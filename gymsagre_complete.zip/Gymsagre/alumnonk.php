<?php
session_start();
if($_SESSION['rol'] !=3){
    header("location: pagprincipal.php");
}
include "conexion.php";
if(!empty($_POST)){
        $mensaje = '';
        $name=$_SESSION['nombre'];
        $old = md5($_POST['oldpass']);
        $new = md5($_POST['newpass']);
    
        $query = mysqli_query($conexion,"SELECT * FROM cliente WHERE clave='$new' AND clinombre !='$name' ");
        $resul = mysqli_fetch_array($query);
        if($resul>0){
            $mensaje='<p class="msg_error">ERROR, INGRESE OTRA NUEVA CONTRASEÑA.</p>';
        }else{
            $query_insert = mysqli_query($conexion,"UPDATE cliente SET clave='$new' WHERE clave='$old' AND clinombre='$name'");
            if($query_insert){
                $mensaje='<p class="msg_save">¡EL CAMBIO SE REALIZÓ CON ÉXITO!</p>';
                $mensaje2='<center><a href="pagprincipal.php" class="newtoshow">REGRESAR</a></center>';
            }else{
                $mensaje='<p class="msg_error">ERROR, NO SE REALIZÓ EL CAMBIO.</p>';
            }
        } mysqli_close($conexion);
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<?php include "scripts.php";?>
<style>
    .botton{
        background: none;
    }
    .newtoshow{
    display:inline-block;
    text-align: center;
    background: #0C03AD;
    color: #FFF;
    padding: 10px 15px;
    border-radius: 13px;
    margin: 10px;
    }
</style>
	<title>Menú</title>
</head>
<body>
	<?php include "header.php";?>
	<section id="container">
		<div class="form_registro">
		    <h1> <i class="fas fa-asterisk"></i> Cambio clave</h1>
		    <hr>
		    <div class="mensaje"><?php echo isset($mensaje) ? $mensaje : ''; ?></div>
		    <div class="mensaje"><?php echo isset($mensaje2) ? $mensaje2 : ''; ?></div>
		    <form action="" method="post">
		        <label for="oldpass">Contraseña Anterior</label>
		        <input type="password" name="oldpass" id="oldpass" placeholder="Ingrese su anterior contraseña" required>
		        <label for="newpass">Nueva Contraseña</label>
		        <input type="password" name="newpass" id="newpass" placeholder="Ingrese Nueva contraseña" required>
                <center><br>
                <button type="button" onclick="myPass()" style="cursor:pointer"><i class="fas fa-eye"></i></button>
                </center>
		        <input type="submit" value="Cambiar" class="user_save">
		    </form>
		</div>
	</section>
	<?php //include "footer.php";?>
</body>
</html>
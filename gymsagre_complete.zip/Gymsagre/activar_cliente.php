<?php
session_start();
if($_SESSION['rol'] !=1){
    header("location: index.php");
}
  include "conexion.php";
  if(empty($_GET)){
          header("location: mostrardel_cliente.php");
          mysqli_close($conexion);
        }
        $idactivecli = $_GET['id'];
        $active = mysqli_query($conexion,"UPDATE cliente SET estatus=1 WHERE idalumno=$idactivecli");
            if($active){
                header("Location: mostrardel_cliente.php");
                }else{
                    echo"<script>alert('Error');</scriptalert>";
                        header("Location: mostrardel_cliente.php");
                }
            ?>
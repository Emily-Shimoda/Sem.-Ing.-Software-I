<?php 
session_start();
if($_SESSION['rol'] !=1){
    header("location: pagprincipal.php");
}
include "conexion.php";
    if(!empty($_POST)){
        $mensaje = '';
        $okey='';
        $nombre = $_POST['nombre'];
        $fecha = $_POST['fecha'];
        $nivel = $_POST['nivel'];
        $telefono = $_POST['telefono'];
        $dir  = $_POST['dir'];
        $mail = $_POST['correo'];
        $user = $_POST['usuario'];
        $clave = md5($_POST['clave']);
        $nomfam = $_POST['familiar'];
        $telfam = $_POST['telfam'];
        $idu= $_POST['idu'];
        
        $query = mysqli_query($conexion,"SELECT * FROM cliente WHERE (usuario = '$user' AND idalumno !=$idu) OR (correo = '$mail' AND idalumno != $idu) OR (clave = '$clave' AND idalumno !=$idu) OR (clinombre = '$nombre' AND idalumno !=$idu)");
        $resul = mysqli_fetch_array($query);
        if($resul>0){
            $mensaje='<p class="msg_error">ERROR, EL USUARIO O CORREO O CLAVE O NOMBRE YA EXISTE.</p>';
        }else{
            if(empty($_POST['clave'])){
                $sql_update = mysqli_query($conexion,"UPDATE cliente SET clinombre='$nombre', fecha_nac='$fecha', nivel='$nivel', telefono='$telefono', direccion='$dir', correo='$mail', usuario='$user', familiar='$nomfam', telfamiliar='$telfam' WHERE idalumno=$idu");
            }else{
                 $sql_update = mysqli_query($conexion,"UPDATE cliente SET clinombre='$nombre', fecha_nac='$fecha', nivel='$nivel', telefono='$telefono', direccion='$dir', correo='$mail', usuario='$user', clave='$clave', familiar='$nomfam', telfamiliar='$telfam' WHERE clinombre=$nombre");
            }
            if($sql_update){
                $mensaje='<p class="msg_save">!El REGISTRO SE HA MODIFICADO CON ÉXITO!</p>';
               $okey='<a href="mostrarcliente.php" class="dir">VER CLIENTES</a></center>';
            }else{
                $mensaje='<p class="msg_error">ERROR, NO SE HA MODIFICADO EL REGISTRO.</p>';
            }
        }
      mysqli_close($conexion);
    }

//mostrar datos 
    if(empty($_GET['id'])){
        header('location: mostrarcliente.php');
        mysqli_close($conexion);
    }
        include "conexion.php";
        $id=$_GET['id'];
        $sql = mysqli_query($conexion,"SELECT * FROM cliente WHERE idalumno=$id");
        mysqli_close($conexion);
        $resul = mysqli_num_rows($sql);
         if($resul == 0){
               header('location: mostrarcliente.php');
           }else{
               while($data = mysqli_fetch_array($sql)){
                     $anombre= $data['clinombre'];
                     $afecha= $data['fecha_nac'] ;
                     $anivel=  $data['nivel'];
                     $atel= $data['telefono']; 
                     $adir= $data['direccion']; 
                     $amail= $data['correo'];
                     $auser= $data['usuario'];
                     $afam= $data['familiar'];
                     $atelfam= $data['telfamiliar'];
                     $aid=$data['idalumno'];
                    }
                }
?>
                
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<?php include "scripts.php";?>
	<title>Modifición De Cliente</title>
</head>
<body>
	<?php include "header.php";?>
	<section id="container">
		<div class="form_registro">
		    <h1><i class="fas fa-user-edit"></i> MODIFICAR CLIENTE</h1>
		    <hr>
		    <div class="mensaje"><?php echo isset($mensaje) ? $mensaje : ''; ?></div>
		    <div class="dir"><?php echo isset($okey)? $okey: '';?></div>
		    <form action="" method="post">
                <input type="hidden" name="idu" value="<?php echo $aid;?>">
		        <label for="nombre">Nombre</label>
		        <input type="text" name="nombre" id="nombre" value="<?php echo $anombre; ?>" required>
		        <label for="fecha_nac">Fecha Nacimiento</label>
		        <input type="date" name="fecha" id="fecha" value="<?php echo $afecha; ?>" required>
		        <label for="nivel">Nivel</label>
		        <input type="text" name="nivel" id="nivel" value="<?php echo $anivel; ?>"required>
		        <label for="telefono">Telefono</label>
		        <input type="tel" name="telefono" id="telefono" value="<?php echo $atel; ?>" required>
		        <label for="dir">Dirección</label>
		        <input type="text" name="dir" id="dir" value="<?php echo $adir; ?>"required>
		        <label for="correo">Mail</label>
		        <input type="email" name="correo" id="correo" value="<?php echo $amail; ?>" required>
		        <label for="usuario">Usuario</label>
		        <input type="text" name="usuario" id="usuario" value="<?php echo $auser; ?>" required>
		        <label for="clave">Contraseña</label>
		        <input type="password" name="clave" id="clave" placeholder="***********">
		        <label for="familiar">Familiar</label>
		        <input type="text" name="familiar" id="familiar" value="<?php echo $afam; ?>" required>
		        <label for="telfam">Telefono Familiar</label>
		        <input type="tel" name="telfam" id="telfam" value="<?php echo $atelfam; ?>" required>
		        
		        <input type="submit" value="Modificar" class="user_save">
		    </form>
		</div>
	</section>
	
	<?php //include "footer.php";?>
</body>
</html>
<?php 
session_start();
if($_SESSION['rol'] !=1){
    header("location: pagprincipal.php");
}
include "conexion.php";
    if(!empty($_POST)){
        $mensaje = '';
        $okey='';
        $nombrea = $_POST['nombre'];
        $usera = $_POST['usuario'];
        $clavea = md5($_POST['clave']);
        $telefonoa = $_POST['telefono'];
        $dira  = $_POST['dir'];
        $maila = $_POST['correo'];
        $ida= $_POST['idu'];
        
        $query = mysqli_query($conexion,"SELECT * FROM admin WHERE (usuario = '$usera' AND id !=$ida) OR (correo = '$maila' AND id != $ida) OR (clave = '$clavea' AND id !=$ida) OR (adminnombre = '$nombrea' AND id !=$ida)");
        $resul = mysqli_fetch_array($query);
        if($resul>0){
            $mensaje='<p class="msg_error">ERROR, EL USUARIO O CORREO O CLAVE O NOMBRE YA EXISTE.</p>';
        }else{
            if(empty($_POST['clave'])){
                $sql_update = mysqli_query($conexion,"UPDATE admin SET adminnombre='$nombrea', usuario='$usera', telefono='$telefonoa', direccion='$dira', correo='$maila' WHERE id=$ida");
            }else{
                 $sql_update = mysqli_query($conexion,"UPDATE admin SET adminnombre='$nombrea', usuario='$usera', clave='$clavea', telefono='$telefonoa', direccion='$dira', correo='$maila' WHERE id=$ida");
            }
            if($sql_update){
                $mensaje='<p class="msg_save">¡El REGISTRO SE HA MODIFICADO CON ÉXITO!</p>';
               $okey='<a href="mostraradmin.php" class="dir">VER ADMINS</a></center>';
            }else{
                $mensaje='<p class="msg_error">ERROR, NO SE HA MODIFICADO EL REGISTRO.</p>';
            }
        }
      mysqli_close($conexion);
    }

//mostrar datos 
    if(empty($_GET['id'])){
        header('location: mostraradmin.php');
        mysqli_close($conexion);
    }
        include "conexion.php";
        $id=$_GET['id'];
        $sql = mysqli_query($conexion,"SELECT * FROM admin WHERE id=$id");
        mysqli_close($conexion);
        $resul = mysqli_num_rows($sql);
         if($resul == 0){
               header('location: mostraradmin.php');
           }else{
               while($data = mysqli_fetch_array($sql)){
                     $anombre= $data['adminnombre'];
                     $auser= $data['usuario'];
                     $atel= $data['telefono']; 
                     $adir= $data['direccion']; 
                     $amail= $data['correo'];
                     $aid=$data['id'];
                    }
                }
?>
                
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<?php include "scripts.php";?>
	<title>Modifición De Administrador</title>
</head>
<body>
	<?php include "header.php";?>
	<section id="container">
		<div class="form_registro">
		    <h1><i class="fas fa-user-edit"></i> MODIFICAR ADMIN</h1>
		    <hr>
		    <div class="mensaje"><?php echo isset($mensaje) ? $mensaje : ''; ?></div>
		    <div class="mensaje"><?php echo isset($okey)? $okey: '';?></div>
		    <form action="" method="post">
                <input type="hidden" name="idu" value="<?php echo $aid;?>">
		        <label for="nombre">Nombre</label>
		        <input type="text" name="nombre" id="nombre" value="<?php echo $anombre; ?>" required>
		        <label for="usuario">Usuario</label>
		        <input type="text" name="usuario" id="usuario" value="<?php echo $auser; ?>" required>
		        <label for="clave">Contraseña</label>
		        <input type="password" name="clave" id="clave" placeholder="***********">
		        <label for="telefono">Teléfono</label>
		        <input type="tel" name="telefono" id="telefono" value="<?php echo $atel; ?>" required>
		        <label for="dir">Dirección</label>
		        <input type="text" name="dir" id="dir" value="<?php echo $adir; ?>"required>
		        <label for="correo">Mail</label>
		        <input type="email" name="correo" id="correo" value="<?php echo $amail; ?>" required>
		        <input type="submit" value="Modificar" class="user_save">
		    </form>
		</div>
	</section>
	
	<?php //include "footer.php";?>
</body>
</html>
<?php
session_start();
 $mensaje = '';
    if(!empty($_SESSION['active'])){
        header('location: index.php');
    }else{
        if(!empty($_POST)){
            if(empty($_POST['usuario']) || empty($_POST['password'])){
                $mensaje = "Todos los campos son requridos";
            }else{
                require_once "conexion.php";
                $user= mysqli_real_escape_string($conexion,$_POST['usuario']);
                $clave= md5(mysqli_real_escape_string($conexion,$_POST['password']));
                $query = mysqli_query($conexion,"SELECT * FROM usuario WHERE username='$user' AND clave='$clave' AND estatus=1");
                $resul= mysqli_num_rows($query);
        if($resul>0){
                        $data = mysqli_fetch_array($query);
                        $nrol=$data['rol'];
            $sql =  mysqli_query($conexion,"SELECT * FROM rol WHERE idrol='$nrol'");
             mysqli_close($conexion);
            $result = mysqli_num_rows($sql);
            if($result >0){
                $datos = mysqli_fetch_array($sql);
                    
                        $_SESSION['active'] = true;
                        $_SESSION['nombre'] = $data['nombre'];
                        $_SESSION['username'] = $data['username'];
                        $_SESSION['nivel'] = $data['nivel'];
                        $_SESSION['rol'] = $data['rol'];
                        $_SESSION['nrol']= $datos['rol'];
                        
                        header('location: pagprincipal.php');
                    }}else{
                            $mensaje = "El usuario o contraeña son incorrectos";
                            session_destroy();
                    }
            }
        }
    }
?>
<!doctype html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Login Gimnasia Sagré</title>
    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Inter">
    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto">
    <link rel="stylesheet" type="text/css" href="css/reset.css">
    <link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
    <div class="titulo">Menú de usuarios de Gimnasia Sagré<p style="display: inline;">&reg;</p></div>
    <section id="container">
        <form action="" method="post">
            <h3>Iniciar Sesión</h3>
            <img src="img/gs.png" alt="Logo" style="border-radius:50%;">
            <input type="text" name="usuario" placeholder="Usuario" required >
            <input type="password" name="password" placeholder="Contraseña" required>
            <div class="alert"><?php echo isset($mensaje)? $mensaje : ''; ?></div>
            <input type="submit" name="click"value="Iniciar sesión">
        </form>
    </section>
</body>
</html>
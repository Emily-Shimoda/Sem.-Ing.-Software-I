<?php 
session_start();
if($_SESSION['rol'] !=1){
    header("location: pagprincipal.php");
}
include "conexion.php";
if(!empty($_POST)){
        $mensaje = '';
        $okey='';
        $idap= $_POST['id'];
        $nombre = $_POST['nombre'];
        $descrip = $_POST['descrip'];
        $mod = $_POST['modelo'];
        $cant  = $_POST['cantidad'];
        
        $query = mysqli_query($conexion,"SELECT * FROM aparato WHERE nombreaparato = '$nombre' AND idaparato !=$idap");
        $resul = mysqli_fetch_array($query);
        if($resul>0){
            $mensaje='<p class="msg_error">ERROR, EL APARATO YA EXISTE.</p>';
        }else{
               $sql_update = mysqli_query($conexion,"UPDATE aparato SET nombreaparato='$nombre', descripcion='$descrip', modelo='$mod',      cantidad='$cant' WHERE idaparato=$idap");
            //comprobacion
            if($sql_update){
                $mensaje='<p class="msg_save">¡El REGISTRO SE HA MODIFICADO CON ÉXITO!</p>';
               $okey='<a href="mostraraparato.php" class="dir">VER APARATOS</a></center>';
            }else{
                $mensaje='<p class="msg_error">ERROR, NO SE HA MODIFICADO EL REGISTRO.</p>';
            }}
        
      mysqli_close($conexion);
    }

//mostrar datos 
    if(empty($_GET['id'])){
        header('location: mostraraparato.php');
        mysqli_close($conexion);
    }
        include "conexion.php";
        $id=$_GET['id'];
        $sql = mysqli_query($conexion,"SELECT * FROM aparato WHERE idaparato=$id");
        mysqli_close($conexion);
        $resul = mysqli_num_rows($sql);
         if($resul == 0){
               header('location: mostraraparato.php');
           }else{
               while($data = mysqli_fetch_array($sql)){
                     $aid=$data['idaparato'];
                     $anombre= $data['nombreaparato'];
                     $adescrip= $data['descripcion'];
                     $amodel= $data['modelo']; 
                     $acant= $data['cantidad'];
                    }
                }
?>
                
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<?php include "scripts.php";?>
	<title>Modifición De Aparato</title>
</head>
<body>
	<?php include "header.php";?>
	<section id="container">
		<div class="form_registro">
		    <h1><i class="fas fa-edit"></i> MODIFICAR APARATO</h1>
		    <hr>
		    <div class="mensaje"><?php echo isset($mensaje) ? $mensaje : ''; ?></div>
		    <div class="mensaje"><?php echo isset($okey)? $okey: '';?></div>
		    <form action="" method="post">
                <input type="hidden" name="id" id="id" value="<?php echo $aid;?>" required>
		        <label for="nombre">Nombre</label>
		        <input type="text" name="nombre" id="nombre" value="<?php echo $anombre; ?>" required>
		        <label for="descrip">Descripción</label>
		        <input type="text" name="descrip" id="descrip" value="<?php echo $adescrip; ?>" required>
		        <label for="modelo">Modelo</label>
		        <input type="text" name="modelo" id="modelo" value="<?php echo $amodel; ?>"required>
		        <label for="cantidad">Existencia</label>
		        <input type="number" name="cantidad" id="candidad" value="<?php echo $acant; ?>" required>
		        <input type="submit" value="Modificar" class="user_save">
		        <input type="button" onclick="location.href='mostraraparato.php'; " value="CANCELAR" class="user_save">
		    </form>
		</div>
	</section>
	
	<?php //include "footer.php";?>
</body>
</html>
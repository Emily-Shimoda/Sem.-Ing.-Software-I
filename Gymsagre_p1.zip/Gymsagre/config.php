<?php
$BD_HOST='localhost';
    $BD_USER='root';
    $BD_PASS='';
    $BD_NAME='gymsagre';
?>
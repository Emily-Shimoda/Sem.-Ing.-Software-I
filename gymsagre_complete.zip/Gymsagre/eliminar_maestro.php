<?php
session_start();
if($_SESSION['rol'] !=1){
    header("location: index.php");
}
  include "conexion.php";
  if(empty($_GET)){
          header("location: mostrarmaestro.php");
          mysqli_close($conexion);
        }
        $iddelma = $_GET['id'];
        $delete = mysqli_query($conexion,"UPDATE maestro SET estatus=0 WHERE idmaestro=$iddelma");
            if($delete){
                header("Location: mostrarmaestro.php");
                }else{
                    echo"<script>alert('Error');</scriptalert>";
                        header("Location: mostrarmaestro.php");
                }
            ?>
<link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Inter">
<link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto">
<link rel="stylesheet" type="text/css" href="css/reset.css">
<link rel="stylesheet" type="text/css" href="css/stiloinicio.css">
<script type="text/javascript" src="javascript/jquery.min.js"></script>
<script type="text/javascript" src="javascript/icons.js"></script>
<script type="text/javascript" src="javascript/confirmar.js"></script>
<script type="text/javascript" src="javascript/confirmarma.js"></script>
<script type="text/javascript" src="javascript/confirmarcli.js"></script>
<script type="text/javascript" src="javascript/confirmapa.js"></script>
<script type="text/javascript" src="javascript/confiractiveadmin.js"></script>
<script type="text/javascript" src="javascript/confirmarho.js"></script>
<script type="text/javascript" src="javascript/show.js"></script>

<link rel="stylesheet" type="text/css" href="css/stile2.css">
<?php include "time.php"; ?>
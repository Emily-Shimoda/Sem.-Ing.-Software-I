-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 20-11-2021 a las 05:03:57
-- Versión del servidor: 10.4.17-MariaDB
-- Versión de PHP: 8.0.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `gymsagre`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `adminnombre` varchar(80) NOT NULL,
  `usuario` varchar(30) NOT NULL,
  `clave` varchar(50) NOT NULL,
  `telefono` varchar(12) NOT NULL,
  `direccion` text NOT NULL,
  `correo` varchar(100) NOT NULL,
  `dateadd` datetime NOT NULL DEFAULT current_timestamp(),
  `estatus` int(11) NOT NULL DEFAULT 1,
  `idrola` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `admin`
--

INSERT INTO `admin` (`id`, `adminnombre`, `usuario`, `clave`, `telefono`, `direccion`, `correo`, `dateadd`, `estatus`, `idrola`) VALUES
(1, 'adminluis', 'adminl', '8ef9ae32e7b1351f139e074c18df9371', '3322196995', 'Rio reforma 1724', 'admib@outlook.com', '2021-11-05 18:58:02', 1, 1),
(23, 'adminprueba', 'pepe', '0b513f96080842a12bd36e2bd42273a6', '23265344', 'nolose homs', 'admin@outlook.com', '2021-11-05 23:27:08', 1, 1),
(24, 'Javier Hernandez', 'javis', 'f9ccffeda0c8523eb662fc65ea58326e', '4565787655', 'Av revolucion #1500', 'javi@gmail.com', '2021-11-07 14:31:48', 1, 1);

--
-- Disparadores `admin`
--
DELIMITER $$
CREATE TRIGGER `atousuario_A_U` AFTER UPDATE ON `admin` FOR EACH ROW BEGIN
    UPDATE usuario SET nombre = new.adminnombre, username = new.usuario, clave = new.clave, rol = old.idrola
    WHERE nombre=old.adminnombre;
IF new.estatus = 0 THEN 
UPDATE usuario SET estatus =0 WHERE
estatus=old.estatus AND nombre=old.adminnombre;
END IF;
IF new.estatus = 1 THEN 
UPDATE usuario SET estatus =1 WHERE
estatus=old.estatus AND nombre=old.adminnombre;
END IF;
    END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `usuaria_A_I` AFTER INSERT ON `admin` FOR EACH ROW BEGIN
    INSERT INTO usuario(nombre,username,clave,rol,estatus)
    VALUES(new.adminnombre,new.usuario,new.clave,new.idrola,new.estatus);
    END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `aparato`
--

CREATE TABLE `aparato` (
  `idaparato` int(11) NOT NULL,
  `nombreaparato` varchar(60) NOT NULL,
  `descripcion` text NOT NULL,
  `modelo` varchar(50) NOT NULL,
  `cantidad` int(11) NOT NULL,
  `estatus` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `aparato`
--

INSERT INTO `aparato` (`idaparato`, `nombreaparato`, `descripcion`, `modelo`, `cantidad`, `estatus`) VALUES
(1623, 'Caminadora', 'Caminadora estandar', 'NordickTrack', 24, 1),
(1763, 'Caminadora Eléctrica', 'Caminadora eléctrica de varios niveles', 'Unifitness', 20, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cliente`
--

CREATE TABLE `cliente` (
  `clinombre` varchar(80) NOT NULL,
  `fecha_nac` date NOT NULL,
  `nivel` varchar(30) NOT NULL,
  `telefono` varchar(12) NOT NULL,
  `direccion` text NOT NULL,
  `correo` varchar(100) NOT NULL,
  `usuario` varchar(30) NOT NULL,
  `clave` varchar(50) NOT NULL,
  `dateadd` datetime NOT NULL DEFAULT current_timestamp(),
  `estatus` int(11) NOT NULL DEFAULT 1,
  `familiar` varchar(60) NOT NULL,
  `telfamiliar` varchar(12) NOT NULL,
  `idrolc` int(11) NOT NULL DEFAULT 3,
  `idalumno` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `cliente`
--

INSERT INTO `cliente` (`clinombre`, `fecha_nac`, `nivel`, `telefono`, `direccion`, `correo`, `usuario`, `clave`, `dateadd`, `estatus`, `familiar`, `telfamiliar`, `idrolc`, `idalumno`) VALUES
('Laura Delgadillo Lariossss', '1952-11-08', '1', '2345677654', 'Av gonzales gallo #7162', 'laurita@outllook.com', 'lau', '680e89809965ec41e64dc7e447f175ab', '2021-11-06 21:47:21', 1, 'lourdez', '234354353343', 3, 3),
('Luis Danie', '1996-12-01', '2', '23265344', 'Rio reforma #1720', 'daniel@outlook.com', 'luda', 'ldzd', '2021-10-28 01:06:58', 1, 'Carla Delgadillo Larios', '3384773655', 3, 2),
('luisdanielzd prueba', '1987-10-07', '3', '332219696523', 'Prueba', 'Prueba', 'prueba', 'c893bad68927b457dbed39460e6afd62', '2021-10-28 01:53:26', 1, 'pruebaf', '74563524', 3, 1);

--
-- Disparadores `cliente`
--
DELIMITER $$
CREATE TRIGGER `usuario_A_I` AFTER INSERT ON `cliente` FOR EACH ROW BEGIN
    INSERT INTO usuario(nombre,username,clave,rol,estatus,nivel)
    VALUES(new.clinombre,new.usuario,new.clave,new.idrolc,new.estatus,new.nivel);
    END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `usuario_A_U` AFTER UPDATE ON `cliente` FOR EACH ROW BEGIN
    UPDATE usuario SET nombre = new.clinombre, username = new.usuario, clave = new.clave, rol = old.idrolc
    WHERE nombre=old.clinombre;
IF new.estatus = 0 THEN 
UPDATE usuario SET estatus =0 WHERE
estatus=old.estatus AND nombre=old.clinombre;
END IF;
IF new.estatus = 1 THEN 
UPDATE usuario SET estatus =1 WHERE
estatus=old.estatus AND nombre=old.clinombre;
END IF;
    END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `horario`
--

CREATE TABLE `horario` (
  `idhorario` int(11) NOT NULL,
  `aparato_select` varchar(60) NOT NULL,
  `maestro` varchar(80) NOT NULL,
  `dia` varchar(20) NOT NULL,
  `hora` time NOT NULL,
  `nivel` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `horario`
--

INSERT INTO `horario` (`idhorario`, `aparato_select`, `maestro`, `dia`, `hora`, `nivel`) VALUES
(1, 'Caminadora Eléctrica', 'Juan Alvarado', 'Lunes', '07:00:00', '1'),
(2, 'Caminadora Eléctrica', 'Juan Alvarado', 'Lunes', '07:00:00', '2'),
(4, 'Caminadora Eléctrica', 'Juan Alvarado', 'Lunes', '07:00:00', '3'),
(5, 'Caminadora', 'William Juarez', 'Martes', '09:30:00', '2');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `maestro`
--

CREATE TABLE `maestro` (
  `maestronombre` varchar(80) NOT NULL,
  `usuario` varchar(30) NOT NULL,
  `clave` varchar(50) NOT NULL,
  `telefono` varchar(12) NOT NULL,
  `direccion` text NOT NULL,
  `correo` varchar(100) NOT NULL,
  `estatus` int(11) NOT NULL DEFAULT 1,
  `dateadd` datetime NOT NULL DEFAULT current_timestamp(),
  `idrolm` int(11) NOT NULL DEFAULT 2,
  `idmaestro` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `maestro`
--

INSERT INTO `maestro` (`maestronombre`, `usuario`, `clave`, `telefono`, `direccion`, `correo`, `estatus`, `dateadd`, `idrolm`, `idmaestro`) VALUES
('Juan Alvarado', 'masterjuan', 'a94652aa97c7211ba8954dd15a3cf838', '3322196995', 'Av ruvalcaba #2663', 'juanmaestro@yahoo.com', 1, '2021-11-05 18:59:51', 2, 1),
('William Juarez', 'willju', '18218139eec55d83cf82679934e5cd75', '34665453', 'Av tonaltecas #454', 'willmaestro@outlook.com', 1, '2021-11-07 13:22:34', 2, 2);

--
-- Disparadores `maestro`
--
DELIMITER $$
CREATE TRIGGER `maestro_A_U` AFTER UPDATE ON `maestro` FOR EACH ROW BEGIN
    UPDATE usuario SET nombre = new.maestronombre, username = new.usuario, clave = new.clave, rol = old.idrolm
    WHERE nombre=old.maestronombre;
IF new.estatus = 0 THEN 
UPDATE usuario SET estatus =0 WHERE
estatus=old.estatus AND nombre=old.maestronombre;
END IF;
IF new.estatus = 1 THEN 
UPDATE usuario SET estatus =1 WHERE
estatus=old.estatus AND nombre=old.maestronombre;
END IF;
    END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `musuario_A_I` AFTER INSERT ON `maestro` FOR EACH ROW BEGIN
    INSERT INTO usuario(nombre,username,clave,rol,estatus)
    VALUES(new.maestronombre,new.usuario,new.clave,'2',new.estatus);
    END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `rol`
--

CREATE TABLE `rol` (
  `idrol` int(11) NOT NULL,
  `rol` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `rol`
--

INSERT INTO `rol` (`idrol`, `rol`) VALUES
(1, 'administrador'),
(2, 'maestro'),
(3, 'cliente');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

CREATE TABLE `usuario` (
  `id` int(11) NOT NULL,
  `nombre` varchar(80) NOT NULL,
  `username` varchar(30) NOT NULL,
  `clave` varchar(50) NOT NULL,
  `rol` int(11) NOT NULL,
  `estatus` int(11) DEFAULT NULL,
  `foto` longblob NOT NULL,
  `nivel` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`id`, `nombre`, `username`, `clave`, `rol`, `estatus`, `foto`, `nivel`) VALUES
(24, 'Luis Danie', 'luda', 'ldzd', 3, 1, '', '2'),
(25, 'luisdanielzd prueba', 'prueba', 'c893bad68927b457dbed39460e6afd62', 3, 1, '', '3'),
(26, 'adminluis', 'adminl', '8ef9ae32e7b1351f139e074c18df9371', 1, 1, '', ''),
(27, 'Juan Alvarado', 'masterjuan', 'a94652aa97c7211ba8954dd15a3cf838', 2, 1, '', ''),
(28, 'adminprueba', 'pepe', '0b513f96080842a12bd36e2bd42273a6', 1, 1, '', ''),
(29, 'Laura Delgadillo Lariossss', 'lau', '680e89809965ec41e64dc7e447f175ab', 3, 1, '', '1'),
(30, 'William Juarez', 'willju', '18218139eec55d83cf82679934e5cd75', 2, 1, '', ''),
(31, 'Javier Hernandez', 'javis', 'f9ccffeda0c8523eb662fc65ea58326e', 1, 1, '', '');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idrola` (`idrola`);

--
-- Indices de la tabla `aparato`
--
ALTER TABLE `aparato`
  ADD PRIMARY KEY (`nombreaparato`);

--
-- Indices de la tabla `cliente`
--
ALTER TABLE `cliente`
  ADD PRIMARY KEY (`clinombre`),
  ADD UNIQUE KEY `idalumno` (`idalumno`),
  ADD KEY `idrolc` (`idrolc`),
  ADD KEY `nivel` (`nivel`);

--
-- Indices de la tabla `horario`
--
ALTER TABLE `horario`
  ADD PRIMARY KEY (`idhorario`),
  ADD KEY `maestro` (`maestro`),
  ADD KEY `aparato_select` (`aparato_select`),
  ADD KEY `nivel` (`nivel`);

--
-- Indices de la tabla `maestro`
--
ALTER TABLE `maestro`
  ADD PRIMARY KEY (`maestronombre`),
  ADD UNIQUE KEY `idmaestro` (`idmaestro`),
  ADD KEY `idrolm` (`idrolm`);

--
-- Indices de la tabla `rol`
--
ALTER TABLE `rol`
  ADD PRIMARY KEY (`idrol`);

--
-- Indices de la tabla `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`id`),
  ADD KEY `rol` (`rol`),
  ADD KEY `nivel` (`nivel`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT de la tabla `cliente`
--
ALTER TABLE `cliente`
  MODIFY `idalumno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `horario`
--
ALTER TABLE `horario`
  MODIFY `idhorario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT de la tabla `maestro`
--
ALTER TABLE `maestro`
  MODIFY `idmaestro` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `rol`
--
ALTER TABLE `rol`
  MODIFY `idrol` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `usuario`
--
ALTER TABLE `usuario`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `admin`
--
ALTER TABLE `admin`
  ADD CONSTRAINT `admin_ibfk_1` FOREIGN KEY (`idrola`) REFERENCES `rol` (`idrol`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `cliente`
--
ALTER TABLE `cliente`
  ADD CONSTRAINT `cliente_ibfk_1` FOREIGN KEY (`idrolc`) REFERENCES `rol` (`idrol`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `horario`
--
ALTER TABLE `horario`
  ADD CONSTRAINT `horario_ibfk_1` FOREIGN KEY (`maestro`) REFERENCES `maestro` (`maestronombre`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `horario_ibfk_2` FOREIGN KEY (`aparato_select`) REFERENCES `aparato` (`nombreaparato`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `horario_ibfk_3` FOREIGN KEY (`nivel`) REFERENCES `cliente` (`nivel`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `maestro`
--
ALTER TABLE `maestro`
  ADD CONSTRAINT `maestro_ibfk_1` FOREIGN KEY (`idrolm`) REFERENCES `rol` (`idrol`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `usuario`
--
ALTER TABLE `usuario`
  ADD CONSTRAINT `usuario_ibfk_1` FOREIGN KEY (`rol`) REFERENCES `rol` (`idrol`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

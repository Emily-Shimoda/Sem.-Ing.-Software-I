<?php 
session_start();
if($_SESSION['rol'] !=1){
    header("location: pagprincipal.php");
}
include "conexion.php";
    if(!empty($_POST)){
        $mensaje = '';
        $nombre = $_POST['nombre'];
        $fecha = $_POST['fecha'];
        $nivel = $_POST['nivel'];
        $telefono = $_POST['telefono'];
        $dir  = $_POST['dir'];
        $mail = $_POST['correo'];
        $user = $_POST['usuario'];
        $clave = md5($_POST['clave']);
        $nomfam = $_POST['familiar'];
        $telfam = $_POST['telfam'];
        
        $query = mysqli_query($conexion,"SELECT * FROM cliente WHERE usuario = '$user' OR correo = '$mail' OR clinombre='$nombre' OR clave='$clave' ");
        $resul = mysqli_fetch_array($query);
        if($resul>0){
            $mensaje='<p class="msg_error">ERROR, LOS DATO(S) DEL CLIENTE A REGISTAR YA EXISTE(N).</p>';
        }else{
            $query_insert = mysqli_query($conexion,"INSERT INTO cliente(clinombre,fecha_nac,nivel,telefono,direccion,correo,usuario,clave,familiar,telfamiliar) VALUES('$nombre', '$fecha','$nivel','$telefono','$dir','$mail','$user','$clave','$nomfam','$telfam')");
            if($query_insert){
                $mensaje='<p class="msg_save">!El REGISTRO SE REALIZÓ CON ÉXITO!</p>';
            }else{
                $mensaje='<p class="msg_error">ERROR, NO SE REALIZO EL REGISTRO.</p>';
            }
        } mysqli_close($conexion);
    }
?>


<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<?php include "scripts.php";?>
<style>
    .newtoshow{
    display:inline-block;
    text-align: center;
    background: #0C03AD;
    color: #FFF;
    padding: 10px 15px;
    border-radius: 13px;
    margin: 10px;
    }
</style>
	<title>Registro De Clientes</title>
</head>
<body>
	<?php include "header.php";?>
	<section id="container">
		<div class="form_registro">
		    <h1> <i class="fas fa-user-plus"></i> REGISTRAR CLIENTE (Alumno)</h1>
		    <hr>
		    <div class="mensaje"><?php echo isset($mensaje) ? $mensaje : ''; ?></div>
		    
		    <form action="" method="post">
		        <label for="nombre">Nombre</label>
		        <input type="text" name="nombre" id="nombre" placeholder="Nombre Completo" required>
		        <label for="fecha_nac">Fehca Nacimiento</label>
		        <input type="date" name="fecha" id="fecha" placeholder="1996-12-10" required>
		        <label for="nivel">Nivel</label>
		        <input type="text" name="nivel" id="nivel" placeholder="Nivel Actual" required>
		        <label for="telefono">Teléfono</label>
		        <input type="tel" name="telefono" id="telefono" placeholder="Introduzca su numero" required>
		        <label for="dir">Dirección</label>
		        <input type="text" name="dir" id="dir" placeholder="Dirección Completa" required>
		        <label for="correo">Mail</label>
		        <input type="email" name="correo" id="correo" placeholder="Correo Electronico" required>
		        <label for="usuario">Usuario</label>
		        <input type="text" name="usuario" id="usuario" placeholder="Nombre de usuario" required>
		        <label for="clave">Contraseña</label>
		        <input type="password" name="clave" id="clave" placeholder="Contraseña" required>
		        <label for="familiar">Familiar</label>
		        <input type="text" name="familiar" id="familiar" placeholder="Nombre Completo Del Familiar" required>
		        <label for="telfam">Telefono Familiar</label>
		        <input type="tel" name="telfam" id="telfam" placeholder="Número telefonico del familiar" required>
		        
		        <input type="submit" value="Registrar" class="user_save">
		    </form>
		    <center><a href="mostrarcliente.php" class="newtoshow">VER CLIENTES  <i class="fas fa-users"></i></a></center>
		</div>
	</section>
	
	<?php //include "footer.php";?>
</body>
</html>
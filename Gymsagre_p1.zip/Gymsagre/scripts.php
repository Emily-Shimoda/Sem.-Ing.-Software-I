<link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Inter">
<link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto">
<link rel="stylesheet" type="text/css" href="css/reset.css">
<link rel="stylesheet" type="text/css" href="css/stiloinicio.css">
<script type="text/javascript" src="javascript/jquery.min.js"></script>
<script type="text/javascript" src="javascript/icons.js"></script>
<link rel="stylesheet" type="text/css" href="css/stile2.css">
<script type="text/javascript" src="javascript/funciones.js"></script>
<?php include "time.php"; ?>
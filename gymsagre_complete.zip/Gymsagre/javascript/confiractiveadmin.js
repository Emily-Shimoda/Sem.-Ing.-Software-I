function activeadmin (event){
    if(confirm("¿Esta seguro que desea Reactivarlo?")){
        return true;
    }else{
        event.preventDefault();
        alert("Acción Cancelada! Registro No Reactivado!");
    }

let linkActive = document.querySelectorAll("activar_admin");

for( var j = 0; j < linkActive.length; j++){
    linkActive[j].addEventListener('clik', activeadmin);
}
}
<?php session_start();?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<?php include "scripts.php";?>
	<title>Sistema Gimnasia Sagré</title>
</head>
<body>
	<?php include "header.php";?>
	<section id="container">
		<h1>Bienvenido</h1>
	</section>
	
	<?php //include "footer.php";?>
</body>
</html>
<nav>
			<ul>
				<li><a href="pagprincipal.php"><i class="fas fa-house-user"></i> Inicio</a></li>
				<?php 
                    if($_SESSION['rol'] ==1){
                 ?>
				<li class="principal">
					<a href="#"><i class="fas fa-users"></i> Administradores</a>
					<ul>
						<li><a href="regisadmin.php"><i class="fas fa-user-plus"></i> Nuevo Administrador</a></li>
						<li><a href="mostraradmin.php"><i class="fas fa-users"></i> Lista De Administradores</a></li>
						<li><a href="mostrardel_admin.php"><i class="fas fa-users-slash"></i> Administradores Eliminados</a></li>
					</ul>
				</li>
				<li class="principal">
					<a href="#"><i class="fas fa-user-tie"></i> Clientes</a>
					<ul>
						<li><a href="regiscliente.php"><i class="fas fa-user-plus"></i> Nuevo Cliente</a></li>
						<li><a href="mostrarcliente.php"><i class="fas fa-users"></i> Lista de Clientes</a></li>
                        <li><a href="contact.php"><i class="far fa-address-book"></i> Lista Contactos De Emergencia</a></li>
						<li><a href="mostrardel_cliente.php"><i class="fas fa-users-slash"></i> Clientes Eliminados</a></li>
					</ul>
				</li>
				<li class="principal">
					<a href="#"><i class="fas fa-chalkboard-teacher"></i> Maestros</a>
					<ul>
						<li><a href="regismaestro.php"><i class="fas fa-user-plus"></i> Nuevo Maestro</a></li>
						<li><a href="mostrarmaestro.php"><i class="fas fa-users"></i> Lista De Maestros</a></li>
						<li><a href="mostrardel_maestro.php"><i class="fas fa-users-slash"></i> Maestros Eliminados</a></li>
					</ul>
				</li>
				<li class="principal">
					<a href="#"><i class="fas fa-cubes"></i> Aparatos</a>
					<ul>
						<li><a href="regisaparato.php"><i class="fas fa-cube"></i> Nuevo Aparato</a></li>
						<li><a href="mostraraparato.php"><i class="fas fa-boxes"></i> Lista De Aparatos</a></li>
						<li><a href="mostrardel_aparato.php"><i class="fas fa-ban"></i> Aparatos Eliminados</a></li>
					</ul>
				</li>
				<?php }?>
				<?php 
                    if($_SESSION['rol'] ==1 || $_SESSION['rol']==2){
                 ?>
				<li class="principal">
					<a href="#"><i class="fas fa-clipboard-check"></i> Horarios</a>
					<ul>
						<li><a href="regishorario.php"><i class="fas fa-plus"></i><i class="fas fa-clipboard-check"></i> Nuevo Horario</a></li>
						<li><a href="mostrarhorario.php"><i class="fas fa-clipboard-list"></i> Lista De Horarios</a></li>
					</ul>
				</li>
				<?php } ?>
				<?php 
                    if($_SESSION['rol'] ==3){
                 ?>
				<li class="principal">
					<a href="#"><i class="fas fa-clipboard-check"></i> Menú</a>
					<ul>
						<li><a href="horarioalumno.php"><i class="fas fa-clipboard-list"></i> Su Horario</a></li>
						<li><a href="alumnonk.php"><i class="fas fa-asterisk"></i> Cambio Contraseña</a></li>
					</ul>
				</li>
				<?php }?>
			</ul>
		</nav>
function myPass(){
            var x = document.getElementById("newpass");
            if(x.type==="password"){
                x.type="text";
            }else{
                x.type="password";
            }
        }
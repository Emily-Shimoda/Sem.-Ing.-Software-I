<?php 
session_start();
if($_SESSION['rol'] !=1 && $_SESSION['rol'] !=2){
    header("location: pagprincipal.php");
}
include "conexion.php";
    if(!empty($_POST)){
        $mensaje = '';
        $aparato = $_POST['aparato'];
        $maestro = $_POST['maestro'];
        $dia = $_POST['dia'];
        $hora  = $_POST['hora'];
        $nivel = $_POST['nivel'];
        
      $query = mysqli_query($conexion,"SELECT * FROM horario WHERE (dia='$dia' AND hora='$hora' AND nivel='$nivel' AND maestro='$maestro' AND aparato_select='$aparato') OR (dia='$dia' AND hora='$hora' AND nivel='$nivel' AND maestro!='$maestro' AND aparato_select='$aparato') ");
        $resul = mysqli_fetch_array($query);
        if($resul>0){
            $mensaje='<p class="msg_error">ERROR, LOS DATO(S) DEL HORARIO A CREAR SE CONFLICTUA CON UNO YA EXISTENTE.</p>';
        }else{
            $query_insert = mysqli_query($conexion,"INSERT INTO `horario` (`aparato_select`, `maestro`, `dia`, `hora`, `nivel`) VALUES ('$aparato', '$maestro', '$dia', '$hora', '$nivel');");
            if($query_insert){
                $mensaje='<p class="msg_save">!El REGISTRO SE REALIZÓ CON ÉXITO!</p>';
            }else{
                $mensaje='<p class="msg_error">ERROR, NO SE REALIZO EL REGISTRO.</p>';
                mysqli_error($conexion);
            }
        } mysqli_close($conexion);
    }
    
?>




<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<?php include "scripts.php";?>
<style>
    .newtoshow{
    display:inline-block;
    text-align: center;
    background: #0C03AD;
    color: #FFF;
    padding: 10px 15px;
    border-radius: 13px;
    margin: 10px;
    }
</style>
	<title>Registro De Horarios</title>
</head>
<body>
	<?php include "header.php";?>
	<section id="container">
		<div class="form_registro">
		    <h1> <i class="fas fa-plus"></i><i class="fas fa-clipboard-check"></i> REGISTRAR HORARIO</h1>
		    <hr>
		    <div class="mensaje"><?php echo isset($mensaje) ? $mensaje : ''; ?></div>
		    
		    <form action="" method="post">
		        <label for="aparato">Aparato</label>
                <?php
                    include "conexion.php";
                    $query_consult = mysqli_query($conexion,"SELECT * FROM aparato ORDER BY nombreaparato ASC");
                     mysqli_close($conexion);
                    $result_apa = mysqli_num_rows($query_consult);
                ?>
		        <select name="aparato" id="aparato">
                <?php
                    if($result_apa > 0){
                        while($apa = mysqli_fetch_array($query_consult)){
                ?>
                    <option value="<?php echo $apa["nombreaparato"]; ?>"><?php echo $apa["nombreaparato"]; ?></option>
                <?php 
                    }   
                    }
                   ?>
                </select>
		        <label for="maestro">Maestro</label>
		         <?php
                if($_SESSION['rol'] !=2){
                    include "conexion.php";
                    $query_consult = mysqli_query($conexion,"SELECT * FROM maestro ORDER BY maestronombre ASC");
                     mysqli_close($conexion);
                    $result_maes = mysqli_num_rows($query_consult);
                ?>
		        <select name="maestro" id="maestro">
                <?php
                    if($result_maes > 0){
                        while($maes = mysqli_fetch_array($query_consult)){
                ?>
                    <option value="<?php echo $maes["maestronombre"]; ?>"><?php echo $maes["maestronombre"]; ?></option>
                <?php 
                    }   
                    }}else{  $maestro=$_SESSION['nombre']?>
                    <input type="text" name="maestro" id="maestro"value="<?php echo $maestro;?>" placeholder="<?php echo $maestro;?>">
                <?php
                          }
                   ?>
                </select>
		        <label for="dia">Día</label>
                  <select name="dia" id="dia">
                    <option value="Lunes">Lunes</option>
                    <option value="Martes">Martes</option>
                    <option value="Miercoles">Miercoles</option>
                    <option value="Jueves">Jueves</option>
                    <option value="Viernes">Viernes</option>
                    <option value="Sabado">Sabado</option>
                    <option value="Domingo">Domingo</option>
                  </select>
		        <label for="hora">Hora:Minuto</label>
		        <input type="time" name="hora" id="hora" required>
		        <label for="nivel">Clase para el nivel:</label>
		        <input type="number" name="nivel" id="nivel" min="1" max="15" placeholder="1" required>
		        <input type="submit" value="Registrar" class="user_save">
		    </form>
		    <center><a href="mostrarhorario.php" class="newtoshow">VER HORARIOS  <i class="fas fa-clipboard-list"></i></a></center>
		</div>
	</section>
	
	<?php //include "footer.php";?>
</body>
</html>
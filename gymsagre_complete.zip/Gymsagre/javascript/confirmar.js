function confirmacion (event){
    if(confirm("¿Esta seguro que desea eliminarlo?")){
        return true;
    }else{
        event.preventDefault();
        alert("Acción Cancelada! Registro No Eliminado!");
    }

let linkDelete = document.querySelectorAll("del_admin");

for( var i = 0; i < linkDelete.length; i++){
    linkDelete[i].addEventListener('clik', confirmacion);
}
}

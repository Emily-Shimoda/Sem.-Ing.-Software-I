<?php
session_start();
if($_SESSION['rol'] !=1){
    header("location: index.php");
}
  include "conexion.php";
  if(empty($_GET)){
          header("location: mostrardel_aparato.php");
          mysqli_close($conexion);
        }
        $idactiveapa = $_GET['id'];
        $active = mysqli_query($conexion,"UPDATE aparato SET estatus=1 WHERE idaparato=$idactiveapa");
            if($active){
                header("Location: mostrardel_aparato.php");
                }else{
                    echo"<script>alert('Error');</scriptalert>";
                        header("Location: mostrardel_aparato.php");
                }
            ?>
<?php 
session_start();
if($_SESSION['rol'] !=1){
    header("location: pagprincipal.php");
}
include "conexion.php";
    if(!empty($_POST)){
        $mensaje = '';
        $okey='';
        $nombrem = $_POST['nombre'];
        $userm = $_POST['usuario'];
        $clavem = md5($_POST['clave']);
        $telefonom = $_POST['telefono'];
        $dirm  = $_POST['dir'];
        $mailm = $_POST['correo'];
        $idm= $_POST['idu'];
        
        $query = mysqli_query($conexion,"SELECT * FROM maestro WHERE (usuario = '$userm' AND idmaestro !=$idm) OR (correo = '$mailm' AND idmaestro != $idm) OR (clave = '$clavem' AND idmaestro !=$idm) OR (maestronombre = '$nombrem' AND idmaestro !=$idm)");
        $resul = mysqli_fetch_array($query);
        if($resul>0){
            $mensaje='<p class="msg_error">ERROR, EL USUARIO O CORREO O CLAVE O NOMBRE YA EXISTE.</p>';
        }else{
            if(empty($_POST['clave'])){
                $sql_update = mysqli_query($conexion,"UPDATE maestro SET maestronombre='$nombrem', usuario='$userm', telefono='$telefonom', direccion='$dirm', correo='$mailm' WHERE idmaestro=$idm");
            }else{
                 $sql_update = mysqli_query($conexion,"UPDATE maestro SET maestronombre='$nombrem', usuario='$userm', clave='$clavem', telefono='$telefonom', direccion='$dirm', correo='$mailm' WHERE idmaestro=$idm");
            }
            if($sql_update){
                $mensaje='<p class="msg_save">!El REGISTRO SE HA MODIFICADO CON ÉXITO!</p>';
               $okey='<a href="mostrarmaestro.php" class="dir">VER MAESTROS</a></center>';
            }else{
                $mensaje='<p class="msg_error">ERROR, NO SE HA MODIFICADO EL REGISTRO.</p>';
            }
        }
      mysqli_close($conexion);
    }

//mostrar datos 
    if(empty($_GET['id'])){
        header('location: mostrarmaestro.php');
        mysqli_close($conexion);
    }
        include "conexion.php";
        $id=$_GET['id'];
        $sql = mysqli_query($conexion,"SELECT * FROM maestro WHERE idmaestro=$id");
        mysqli_close($conexion);
        $resul = mysqli_num_rows($sql);
         if($resul == 0){
               header('location: mostrarmaestro.php');
           }else{
               while($data = mysqli_fetch_array($sql)){
                     $anombre= $data['maestronombre'];
                     $auser= $data['usuario'];
                     $atel= $data['telefono']; 
                     $adir= $data['direccion']; 
                     $amail= $data['correo'];
                     $aid=$data['idmaestro'];
                    }
                }
?>
                
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<?php include "scripts.php";?>
	<title>Modifición De Maestro</title>
</head>
<body>
	<?php include "header.php";?>
	<section id="container">
		<div class="form_registro">
		    <h1><i class="fas fa-user-edit"></i> MODIFICAR MAESTRO</h1>
		    <hr>
		    <div class="mensaje"><?php echo isset($mensaje) ? $mensaje : ''; ?></div>
		    <div class="dir"><?php echo isset($okey)? $okey: '';?></div>
		    <form action="" method="post">
                <input type="hidden" name="idu" value="<?php echo $aid;?>">
		        <label for="nombre">Nombre</label>
		        <input type="text" name="nombre" id="nombre" value="<?php echo $anombre; ?>" required>
		        <label for="usuario">Usuario</label>
		        <input type="text" name="usuario" id="usuario" value="<?php echo $auser; ?>" required>
		        <label for="clave">Contraseña</label>
		        <input type="password" name="clave" id="clave" placeholder="***********">
		        <label for="telefono">Telefono</label>
		        <input type="tel" name="telefono" id="telefono" value="<?php echo $atel; ?>" required>
		        <label for="dir">Dirección</label>
		        <input type="text" name="dir" id="dir" value="<?php echo $adir; ?>"required>
		        <label for="correo">Mail</label>
		        <input type="email" name="correo" id="correo" value="<?php echo $amail; ?>" required>
		        <input type="submit" value="Modificar" class="user_save">
		    </form>
		</div>
	</section>
	
	<?php //include "footer.php";?>
</body>
</html>
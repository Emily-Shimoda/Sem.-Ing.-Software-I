<?php
session_start();
if($_SESSION['rol'] !=1){
    header("location: index.php");
}
  include "conexion.php";
  if(empty($_GET)){
          header("location: mostraraparato.php");
          mysqli_close($conexion);
        }
        $iddelapa = $_GET['id'];
        $delete = mysqli_query($conexion,"UPDATE aparato SET estatus=0 WHERE idaparato=$iddelapa");
            if($delete){
                header("Location: mostraraparato.php");
                }else{
                    echo"<script>alert('Error');</scriptalert>";
                        header("Location: mostraraparato.php");
                }
            ?>
<?php 
session_start();
if($_SESSION['rol'] !=1){
    header("location: pagprincipal.php");
}
include "conexion.php";
    if(!empty($_POST)){
        $mensaje = '';
        $id= $_POST['idnum'];
        $nombre = $_POST['nombre'];
        $descrip = $_POST['descrip'];
        $mod = $_POST['modelo'];
        $cant  = $_POST['cantidad'];
       
        
        $query = mysqli_query($conexion,"SELECT * FROM aparato WHERE nombreaparato = '$nombre' ");
        $resul = mysqli_fetch_array($query);
        if($resul>0){
            $mensaje='<p class="msg_error">ERROR, EL APARATO YA EXISTE.</p>';
        }else{
            $query_insert = mysqli_query($conexion,"INSERT INTO aparato(idaparato,nombreaparato,descripcion,modelo,cantidad) VALUES('$id','$nombre','$descrip','$mod', '$cant')");
            if($query_insert){
                $mensaje='<p class="msg_save">!El REGISTRO SE REALIZÓ CON ÉXITO!</p>';
            }else{
                $mensaje='<p class="msg_error">ERROR, NO SE REALIZO EL REGISTRO.</p>';
            }
        } mysqli_close($conexion);
    }
?>


<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<?php include "scripts.php";?>
<style>
    .newtoshow{
    display:inline-block;
    text-align: center;
    background: #0C03AD;
    color: #FFF;
    padding: 10px 15px;
    border-radius: 13px;
    margin: 10px;
    }
</style>
	<title>Registro De Aparatos</title>
</head>
<body>
	<?php include "header.php";?>
	<section id="container">
		<div class="form_registro">
		    <h1> <i class="fas fa-cube"></i> REGISTRAR APARATO</h1>
		    <hr>
		    <div class="mensaje"><?php echo isset($mensaje) ? $mensaje : ''; ?></div>
		    
		    <form action="" method="post">
                <label for="idnum">Número ID</label>
		        <input type="number" name="idnum" id="idnum" placeholder="Número de identificador" required>
		        <label for="nombre">Nombre</label>
		        <input type="text" name="nombre" id="nombre" placeholder="Nombre Del Aparato" required>
		        <label for="descrip">Descripción</label>
		        <input type="text" name="descrip" id="descrip" placeholder="Descripción del aparato" required>
		        <label for="modelo">Modelo</label>
		        <input type="text" name="modelo" id="modelo" placeholder="Modelo del aparato" required>
		        <label for="cantidad">Existencia</label>
		        <input type="number" name="cantidad" id="cantidad" placeholder="Cantidad Existente" required>
		        
		        <input type="submit" value="Registrar" class="user_save">
		    </form>
		    <center><a href="mostraraparato.php" class="newtoshow">VER APARATOS  <i class="fas fa-boxes"></i></a></center>
		</div>
	</section>
	
	<?php //include "footer.php";?>
</body>
</html>
<?php
session_start();
if($_SESSION['rol'] !=1){
    header("location: pagprincipal.php");
}
 include "conexion.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<link rel="stylesheet" type="text/css" href="css/stilo_usuarios.css">
	<?php include "scripts.php";?>
	<style>
    .del_maestro{
    color: #BC0F00;
}
    .paginador ul{
    padding: 1px;
    margin-top: 10px;
    background: #FFF;
    list-style: none;
	display: flex;
    justify-content: flex-end;
}
.paginador a, .selectedpage{
    color: #0C03AD;
    padding: 5px;
    display: inline-block;
    font-size:  14px;
    text-align: center;
    width: 35px;
    font-family: 'Roboto';
}
.paginador a:hover{
    background: #0C03AD;
    color: #FFFFFF;
}
.selectedpage{
    color: #FFF;
    background: #BC0F00;
}
.buscar_user{
    display: flex;
    float: right;
    padding: 10px;
    border-radius: 5px solid;
    background: initial;
    width: 500px;
}
.buscauser{
    color: #FFF;
    padding:0 8px;
    background: #0C03AD;
    border: 0;
    height: 32.5px;
    cursor: pointer;
    margin: 2px;
}
    </style>
	<title>LISTA DE MAESTROS</title>
</head>
<body>
	<?php include "header.php";?>
	<section id="container">
		<div class="lista_usuario">
		   <h1><i class="fas fa-users"></i> LISTA DE MAESTROS</h1>
		    <hr>
		<center><a href="regismaestro.php" class="new_user">REGISTRAR MAESTRO <i class="fas fa-user-plus"></i></a></center>
		<form action="buscar_maestro.php" method="post" class="buscar_user">
		    <input type="text" name="busqueda" id="busquedau" placeholder="Busque por nombre, usuario o correo">
		    <button type="submit" class="buscauser" name="bus"><i class="fas fa-search fa-lg"></i></button>
		    
		</form>
		<table>
            <tr>
                <th>Nombre</th>
                <th>Usuario</th>
                <th>Teléfono</th>
                <th>Dirección</th>
                <th>Correo</th>
                <th>Ingreso</th>
                <th>Acciones</th>
		    </tr>
        <?php 
            //paginador
            $registros= mysqli_query($conexion,"SELECT COUNT(*) as total_registros FROM maestro WHERE estatus=1");
            $result_regis = mysqli_fetch_array($registros);
            $total_regis= $result_regis['total_registros'];
            $por_pagina = 5;
            if(empty($_GET['pagina'])){
                $pagina=1;
            }else{
                $pagina=$_GET['pagina'];
            }
            $desde = ($pagina-1) * $por_pagina;
            $total_paginas = ceil($total_regis / $por_pagina);
            
        $query=mysqli_query($conexion,"SELECT * FROM maestro WHERE estatus=1 ORDER BY maestronombre ASC LIMIT $desde,$por_pagina ");
            mysqli_close($conexion);
        $result = mysqli_num_rows($query);
            if($result > 0){
                while($datos = mysqli_fetch_array($query)){
                    $datos["idmaestro"];
        ?>
            
		    <tr>
		        <td><?php echo $datos["maestronombre"] ?></td>
		        <td><?php echo $datos["usuario"] ?></td>
		        <td><?php echo $datos["telefono"] ?></td>
		        <td><?php echo $datos["direccion"] ?></td>
		        <td><?php echo $datos["correo"] ?></td>
		        <td><?php echo $datos["dateadd"] ?></td>
		        <td>
		            <a href="modificar_maestro.php?id=<?php echo $datos["idmaestro"] ?>" class="modificar_user"><i class="fas fa-edit"></i> Modificar</a>
		            |
		            <a onclick="confirmacionma(event)" href="eliminar_maestro.php?id=<?php echo $datos["idmaestro"] ?>" class="del_maestro"><i class="fas fa-trash-alt"></i> Eliminar</a>
		        </td>
		    </tr>
        <?php
		          }
            }               
        ?>
		</table>
		</div>
		<div class="paginador">
		  <ul>
        <?php 
              if($pagina!= 1 && $result !=0){
              ?>
		    <li><a href="?pagina=<?php echo 1;?>"><i class="fas fa-step-backward"></i></a></li>
		    <li><a href="?pagina=<?php echo $pagina-1;?>"><i class="fas fa-caret-left"></i></a></li
            <?php
                }
                for ($i=1; $i<=$total_paginas; $i++){
                    if($i == $pagina){ 
                        echo '<li class="selectedpage">'.$i.'</li>';
                }  
                else{
                     echo '<li><a href="?pagina='.$i.'">'.$i.'</a></li>';
                }
                    }
                if($pagina !=$total_paginas && $result !=0){
                ?>
            <li><a href="?pagina=<?php echo $pagina+1;?>"><i class="fas fa-caret-right "></i></a></li>
            <li><a href="?pagina=<?php echo $total_paginas;?>"><i class="fas fa-step-forward"></i></a></li>
            <?php }?>
		  </ul>
		</div>
	</section>
	
	<?php //include "footer.php";?>
</body>
</html>
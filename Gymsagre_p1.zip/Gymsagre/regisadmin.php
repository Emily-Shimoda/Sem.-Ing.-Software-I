<?php 
session_start();
if($_SESSION['rol'] !=1){
    header("location: pagprincipal.php");
}
include "conexion.php";
    if(!empty($_POST)){
        $mensaje = '';
        $nombrea = $_POST['nombre'];
        $usera = $_POST['usuario'];
        $clavea = md5($_POST['clave']);
        $telefonoa = $_POST['telefono'];
        $dira  = $_POST['dir'];
        $maila = $_POST['correo'];
       
        
        $query = mysqli_query($conexion,"SELECT * FROM admin WHERE usuario = '$usera' OR correo = '$maila' OR adminnombre='$nombrea' OR clave='$clavea' ");
        $resul = mysqli_fetch_array($query);
        if($resul>0){
            $mensaje='<p class="msg_error">ERROR, LOS DATO(S) DEL ADMINISTRADOR A REGISTAR YA EXISTE(N).</p>';
        }else{
            $query_insert = mysqli_query($conexion,"INSERT INTO admin(adminnombre,usuario,clave,telefono,direccion,correo) VALUES('$nombrea','$usera','$clavea','$telefonoa','$dira','$maila')");
            if($query_insert){
                $mensaje='<p class="msg_save">!El REGISTRO SE REALIZÓ CON ÉXITO!</p>';
            }else{
                $mensaje='<p class="msg_error">ERROR, NO SE REALIZO EL REGISTRO.</p>';
            }
        } mysqli_close($conexion);
    }
?>


<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<?php include "scripts.php";?>
<style>
    .newtoshow{
    display:inline-block;
    text-align: center;
    background: #0C03AD;
    color: #FFF;
    padding: 10px 15px;
    border-radius: 13px;
    margin: 10px;
    }
</style>
	<title>Registro De Administradores</title>
</head>
<body>
	<?php include "header.php";?>
	<section id="container">
		<div class="form_registro">
		    <h1> <i class="fas fa-user-plus"></i> REGISTRAR ADMIN</h1>
		    <hr>
		    <div class="mensaje"><?php echo isset($mensaje) ? $mensaje : ''; ?></div>
		    
		    <form action="" method="post">
		        <label for="nombre">Nombre</label>
		        <input type="text" name="nombre" id="nombre" placeholder="Nombre Completo" required>
		        <label for="usuario">Usuario</label>
		        <input type="text" name="usuario" id="usuario" placeholder="Nombre de usuario" required>
		        <label for="clave">Contraseña</label>
		        <input type="password" name="clave" id="clave" placeholder="Contraseña" required>
		        <label for="telefono">Teléfono</label>
		        <input type="tel" name="telefono" id="telefono" placeholder="Introduzca su numero" required>
		        <label for="dir">Dirección</label>
		        <input type="text" name="dir" id="dir" placeholder="Dirección Completa" required>
		        <label for="correo">Mail</label>
		        <input type="email" name="correo" id="correo" placeholder="Correo Electronico" required>
		        
		        <input type="submit" value="Registrar" class="user_save">
		    </form>
		    <center><a href="mostraradmin.php" class="newtoshow">VER ADMINS  <i class="fas fa-users"></i></a></center>
		</div>
	</section>
	
	<?php //include "footer.php";?>
</body>
</html>
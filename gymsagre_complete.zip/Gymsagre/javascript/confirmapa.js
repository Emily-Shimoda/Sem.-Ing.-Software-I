function confirmacionapa(event){
    if(confirm("¿Esta seguro que desea eliminarlo?")){
        return true;
    }else{
        event.preventDefault();
        alert("Acción Cancelada! Registro No Eliminado!");
    }



let linkDeleteapa = document.querySelectorAll("del_apa");

for( var i = 0; i < linkDeleteapa.length; i++){
    linkDeleteapa[i].addEventListener('clik', confirmacionapa);
}
}
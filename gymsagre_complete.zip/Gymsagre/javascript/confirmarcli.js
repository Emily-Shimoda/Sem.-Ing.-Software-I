function confirmacioncli(event){
    if(confirm("¿Esta seguro que desea eliminarlo?")){
        return true;
    }else{
        event.preventDefault();
        alert("Acción Cancelada! Registro No Eliminado!");
    }



let linkDeletecli = document.querySelectorAll("del_cli");

for( var i = 0; i < linkDeletecli.length; i++){
    linkDeletecli[i].addEventListener('clik', confirmacioncli);
}
}
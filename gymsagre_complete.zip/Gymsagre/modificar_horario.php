<?php 
session_start();
if($_SESSION['rol'] !=1 && $_SESSION['rol'] !=2){
    header("location: pagprincipal.php");
}
include "conexion.php";
if(!empty($_POST)){
        $mensaje = '';
        $okey='';
        $idh= $_POST['id'];
        $aparato = $_POST['aparato'];
        $maestro = $_POST['maestro'];
        $dia = $_POST['dia'];
        $hora  = $_POST['hora'];
        $nivel = $_POST['nivel'];
        
        $query = mysqli_query($conexion,"SELECT * FROM horario WHERE (dia='$dia' AND hora='$hora' AND nivel='$nivel' AND maestro='$maestro' AND aparato_select='$aparato' AND idhorario !=$idh) OR (dia='$dia' AND hora='$hora' AND nivel='$nivel' AND maestro!='$maestro' AND aparato_select='$aparato' AND idhorario !=$idh)");
        $resul = mysqli_fetch_array($query);
        if($resul>0){
            $mensaje='<p class="msg_error">ERROR, LA MODIFICACIÓN DE ESTE HORARIO SE CONFLICTUA CON UNO YA EXISTENTE.</p>';
        }else{
               $sql_update = mysqli_query($conexion,"UPDATE horario SET aparato_select='$aparato', maestro='$maestro', dia='$dia',      hora='$hora', nivel='$nivel' WHERE idhorario=$idh");
            //comprobacion
            if($sql_update){
                $mensaje='<p class="msg_save">!El REGISTRO SE HA MODIFICADO CON ÉXITO!</p>';
               $okey='<a href="mostrarhorario.php" class="dir">VER APARATOS</a></center>';
            }else{
                $mensaje='<p class="msg_error">ERROR, NO SE HA MODIFICADO EL REGISTRO.</p>';
            }}
        
      mysqli_close($conexion);
    }

//mostrar datos 
    if(empty($_GET['id'])){
        header('location: mostrarhorario.php');
        mysqli_close($conexion);
    }
        include "conexion.php";
        $id=$_GET['id'];
        $sql = mysqli_query($conexion,"SELECT * FROM horario WHERE idhorario=$id");
        mysqli_close($conexion);
        $resul = mysqli_num_rows($sql);
         if($resul == 0){
               header('location: mostrarhorario.php');
           }else{
               while($data = mysqli_fetch_array($sql)){
                     $hid=$data['idhorario'];
                     $apaselect= $data['aparato_select'];
                     $hmaestro= $data['maestro'];
                     $hdia= $data['dia']; 
                     $hora= $data['hora'];
                     $hnivel=$data['nivel'];
                    }
                }
?>
                
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<?php include "scripts.php";?>
	<title>Modifición De Horario</title>
</head>
<body>
	<?php include "header.php";?>
	<section id="container">
		<div class="form_registro">
		    <h1><i class="fas fa-edit"></i> MODIFICAR HORARIO</h1>
		    <hr>
		    <div class="mensaje"><?php echo isset($mensaje) ? $mensaje : ''; ?></div>
		    <div class="mensaje"><?php echo isset($okey)? $okey: '';?></div>
		    <form action="" method="post">
                <input type="hidden" name="id" id="id" value="<?php echo $hid;?>" required>
                <?php
                    include "conexion.php";
                    $query_consult = mysqli_query($conexion,"SELECT * FROM aparato ORDER BY nombreaparato ASC");
                     mysqli_close($conexion);
                    $result_apa = mysqli_num_rows($query_consult);
                ?>
                <label for="aparato">Aparato Actaual</label>
		        <select name="aparato" id="aparato">
                <option name="aparato" id="aparato" value="<?php echo $apaselect; ?>">*<?php echo $apaselect;?>*</option> 
                <?php
                    if($result_apa > 0){
                        while($apa = mysqli_fetch_array($query_consult)){
                ?>  
                   
                    <option value="<?php echo $apa["nombreaparato"]; ?>"><?php echo $apa["nombreaparato"]; ?></option>
                    
                <?php 
                    }   
                    }
                   ?>
                </select>
                <label for="maestro">Maestro Actual</label>
		         <?php
                if($_SESSION['rol'] !=2){
                    include "conexion.php";
                    $query_consult = mysqli_query($conexion,"SELECT * FROM maestro ORDER BY maestronombre ASC");
                     mysqli_close($conexion);
                    $result_maes = mysqli_num_rows($query_consult);
                ?>
		        <select name="maestro" id="maestro">
                 <option name="maestro" id="maestro" value="<?php echo $hmaestro; ?>">*<?php echo $hmaestro ?>*</option>
                <?php
                    if($result_maes > 0){
                        while($maes = mysqli_fetch_array($query_consult)){
                ?>
                    <option value="<?php echo $maes["maestronombre"]; ?>"><?php echo $maes["maestronombre"]; ?></option>
                <?php 
                    }   
                    }}else{  $maestro=$_SESSION['nombre']?>
                    <input type="text" name="maestro" id="maestro"value="<?php echo $maestro;?>" placeholder="<?php echo $maestro;?>">
                <?php
                          }
                   ?>
                </select>
		        <label for="dia">Día Actual</label>
                  <select name="dia" id="dia">
                   <option value="<?php echo $hdia;?>">*<?php echo $hdia?>*</option>
                    <option value="Lunes">Lunes</option>
                    <option value="Martes">Martes</option>
                    <option value="Miercoles">Miercoles</option>
                    <option value="Jueves">Jueves</option>
                    <option value="Viernes">Viernes</option>
                    <option value="Sabado">Sabado</option>
                    <option value="Domingo">Domingo</option>
                  </select>
                  <label for="hora">Hora:Minuto Actual</label>
		        <input type="time" name="hora" id="hora" value="<?php echo $hora;?>" required>
		        <label for="nivel">Clase para el nivel actual:</label>
		        <input type="number" name="nivel" id="nivel" value="<?php echo $hnivel; ?>" min="1" max="15" required>
		        <input type="submit" value="Modificar" class="user_save">
		        <input type="button" onclick="location.href='mostrarhorario.php'; " value="CANCELAR" class="user_save">
		    </form>
		</div>
	</section>
	
	<?php //include "footer.php";?>
</body>
</html>
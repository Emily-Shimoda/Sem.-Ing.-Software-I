<?php
session_start();
if($_SESSION['rol'] !=1){
    header("location: index.php");
}
  include "conexion.php";
  if(empty($_GET)){
          header("location: mostrardel_admin.php");
          mysqli_close($conexion);
        }
        $idactive = $_GET['id'];
        $active = mysqli_query($conexion,"UPDATE admin SET estatus=1 WHERE id=$idactive");
            if($active){
                header("Location: mostrardel_admin.php");
                }else{
                    echo"<script>alert('Error');</scriptalert>";
                        header("Location: mostrardel_admin.php");
                }
            ?>
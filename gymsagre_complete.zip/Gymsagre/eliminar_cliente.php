<?php
session_start();
if($_SESSION['rol'] !=1){
    header("location: index.php");
}
  include "conexion.php";
  if(empty($_GET)){
          header("location: mostrarcliente.php");
          mysqli_close($conexion);
        }
        $iddelcli = $_GET['id'];
        $delete = mysqli_query($conexion,"UPDATE cliente SET estatus=0 WHERE idalumno=$iddelcli");
            if($delete){
                header("Location: mostrarcliente.php");
                }else{
                    echo"<script>alert('Error');</scriptalert>";
                        header("Location: mostrarcliente.php");
                }
            ?>
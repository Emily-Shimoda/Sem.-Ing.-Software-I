<?php
session_start();
if($_SESSION['rol'] !=1 || $_SESSION['rol'] !=2){
    header("location: index.php");
}
  include "conexion.php";
  if(empty($_GET)){
          header("location: mostrarhorario.php");
          mysqli_close($conexion);
        }
        $iddelho = $_GET['id'];
        $delete = mysqli_query($conexion,"DELETE FROM horario WHERE idhorario=$iddelho");
            if($delete){
                header("Location: mostrarhorario.php");
                }else{
                    echo"<script>alert('Error');</scriptalert>";
                        header("Location: mostrarhorario.php");
                }
            ?>
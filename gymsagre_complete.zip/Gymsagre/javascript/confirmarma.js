function confirmacionma(event){
    if(confirm("¿Esta seguro que desea eliminarlo?")){
        return true;
    }else{
        event.preventDefault();
        alert("Acción Cancelada! Registro No Eliminado!");
    }



let linkDeletema = document.querySelectorAll("del_maestro");

for( var i = 0; i < linkDeletema.length; i++){
    linkDeletema[i].addEventListener('clik', confirmacionma);
}
}
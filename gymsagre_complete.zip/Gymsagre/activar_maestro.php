<?php
session_start();
if($_SESSION['rol'] !=1){
    header("location: index.php");
}
  include "conexion.php";
  if(empty($_GET)){
          header("location: mostrardel_maestro.php");
          mysqli_close($conexion);
        }
        $idactivema = $_GET['id'];
        $active = mysqli_query($conexion,"UPDATE maestro SET estatus=1 WHERE idmaestro=$idactivema");
            if($active){
                header("Location: mostrardel_maestro.php");
                }else{
                    echo"<script>alert('Error');</scriptalert>";
                        header("Location: mostrardel_maestro.php");
                }
            ?>
<?php 
session_start();
if($_SESSION['rol'] !=1){
    header("location: index.php");
}
 include "conexion.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<link rel="stylesheet" type="text/css" href="css/stilo_usuarios.css">
	<?php include "scripts.php";?>
	<style>
   
    .paginador ul{
    padding: 1px;
    margin-top: 10px;
    background: #FFF;
    list-style: none;
	display: flex;
    justify-content: flex-end;
}
.paginador a, .selectedpage{
    color: #0C03AD;
    padding: 5px;
    display: inline-block;
    font-size:  14px;
    text-align: center;
    width: 35px;
    font-family: 'Roboto';
}
.paginador a:hover{
    background: #0C03AD;
    color: #FFFFFF;
}
.selectedpage{
    color: #FFF;
    background: #BC0F00;
}
.activar_apa{
    color:#0C03AD;
}
.buscar_user{
    display: flex;
    float: right;
    padding: 10px;
    border-radius: 5px solid;
    background: initial;
    width: 500px;
}
.buscauser{
    color: #FFF;
    padding:0 8px;
    background: #0C03AD;
    border: 0;
    height: 32.5px;
    cursor: pointer;
    margin: 2px;
}
    </style>
	<title>LISTA DE APARATOS ELIMINADOS</title>
</head>
<body>
	<?php include "header.php";?>
	<section id="container">
		<div class="lista_usuario">
		   <h1><i class="fas fa-ban"></i> LISTA DE APARATOS ELIMINADOS</h1>
		    <hr>
    <form action="busdelapa.php" method="post" class="buscar_user">
		    <input type="text" name="busqueda" id="busquedau" placeholder="Busque por nombre o modelo">
		    <button type="submit" class="buscauser"><i class="fas fa-search fa-lg"></i></button>  
    </form>
		<table>
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Descripción</th>
                <th>Modelo</th>
                <th>Cantidad</th>
                <th>Acciones</th>
		    </tr>
        <?php 
            //paginador
            $registros= mysqli_query($conexion,"SELECT COUNT(*) as total_registros FROM aparato WHERE estatus=0");
            $result_regis = mysqli_fetch_array($registros);
            $total_regis= $result_regis['total_registros'];
            $por_pagina = 5;
            if(empty($_GET['pagina'])){
                $pagina=1;
            }else{
                $pagina=$_GET['pagina'];
            }
            $desde = ($pagina-1) * $por_pagina;
            $total_paginas = ceil($total_regis / $por_pagina);
            
        $query=mysqli_query($conexion,"SELECT * FROM aparato WHERE estatus=0 ORDER BY idaparato ASC LIMIT $desde,$por_pagina ");
            mysqli_close($conexion);
        $result = mysqli_num_rows($query);
            if($result > 0){
                while($datos = mysqli_fetch_array($query)){
        ?>
            
		    <tr>
		        <td><?php echo $datos["idaparato"] ?></td>
		        <td><?php echo $datos["nombreaparato"] ?></td>		       
		        <td><?php echo $datos["descripcion"] ?></td>
		        <td><?php echo $datos["modelo"] ?></td>
		        <td><?php echo $datos["cantidad"] ?></td>
		        <td>
		            <a onclick="activeapa(event)" href="activar_aparato.php?id=<?php echo $datos["idaparato"] ?>" class="activar_apa"><i class="fas fa-user-check"></i> ACTIVAR</a>
		        </td>
		    </tr>
        <?php
		          }
            }else{
                echo'<center><p style="color:#01F70C">SIN APARATOS ELIMINADOS</p></center>';
            }
        ?>
		</table>
		</div>
		<div class="paginador">
		  <ul>
        <?php 
              if($pagina!= 1 && $result !=0 ){
              ?>
		    <li><a href="?pagina=<?php echo 1;?>">|<</a></li>
		    <li><a href="?pagina=<?php echo $pagina-1;?>"><<</a></li
            <?php
                }
                for ($i=1; $i<=$total_paginas; $i++){
                    if($i == $pagina){ 
                        echo '<li class="selectedpage">'.$i.'</li>';
                }  
                else{
                     echo '<li><a href="?pagina='.$i.'">'.$i.'</a></li>';
                }
                    }
                if($pagina !=$total_paginas && $result !=0 ){
                ?>
            <li><a href="?pagina=<?php echo $pagina+1;?>">>></a></li>
            <li><a href="?pagina=<?php echo $total_paginas;?>">>|</a></li>
            <?php }?>
		  </ul>
		</div>
	</section>
	<script type="text/javascript" >
                    function activeapa (event){
                    if(confirm("¿Esta seguro que desea Reactivarlo?")){
                        return true;
                    }else{
                        event.preventDefault();
                        alert("Acción Cancelada, !Registro No Reactivado!");
                    }

                let linkActive = document.querySelectorAll("activar_apa");

                for( var j = 0; j < linkActive.length; j++){
                    linkActive[j].addEventListener('clik', activecli);
                }
                    }
    
    </script>
</body>
</html>
<?php
require("config.php");
    $conexion = mysqli_connect($BD_HOST,$BD_USER,$BD_PASS,$BD_NAME);
    if(!$conexion){
        echo "Error al conectarse";
    }/*else{
        echo "Conexion Exitosa";
    }*/
?>